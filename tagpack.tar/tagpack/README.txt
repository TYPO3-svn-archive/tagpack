
Feel free to add some documentation or simply add a link to the online manual.
