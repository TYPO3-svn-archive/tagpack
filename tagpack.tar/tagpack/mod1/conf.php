<?php

	// DO NOT REMOVE OR CHANGE THESE 3 LINES:
define('TYPO3_MOD_PATH', '../typo3conf/ext/tagpack/mod1/');
$BACK_PATH='../../../../typo3/';
$MCONF['name']='user_txtagpackM1';

	
$MCONF['access']='user,group';
$MCONF['script']='index.php';

$MLANG['default']['tabs_images']['tab'] = 'moduleicon.gif';
$MLANG['default']['ll_ref']='LLL:EXT:tagpack/mod1/locallang_mod.xml';
?>